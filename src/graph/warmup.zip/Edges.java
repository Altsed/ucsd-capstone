package graph;

public class Edges {
	int from;
	int to;
}
